export class CartPage {
  constructor(page) {
    this.page = page;
    this.cartIcon = page.locator('.shopping_cart_link');
    this.cartItems = page.locator('.cart_item');
  }

  async openCart() {
    await this.cartIcon.click();
  }

  async validateCartItems() {
    const count = await this.cartItems.count();
    if (count !== 2) throw new Error('Cart does not have 2 items');
  }
}
