export class OrderConfirmationPage {
  constructor(page) {
    this.page = page;
    this.successMsg = page.locator('.complete-header');
  }

  async verifySuccessMessage() {
    await this.successMsg.waitFor();
    const msg = await this.successMsg.textContent();
    if (msg.trim() !== 'Thank you for your order!') {
      throw new Error('Order success message not found');
    }
  }
}
