export class InventoryPage {
  constructor(page) {
    this.page = page;
    this.sortDropdown = page.locator('[data-test="product-sort-container"]');
    this.inventoryItems = page.locator('.inventory_item');
    this.cartButton = id => page.locator(`#add-to-cart-${id}`);
  }

  async sortLowToHigh() {
    await this.sortDropdown.selectOption('lohi');
  }

  async addTwoCheapestItems() {
    const items = await this.inventoryItems.all();
    const cheapestTwo = items.slice(0, 2);
    for (const item of cheapestTwo) {
      const name = await item.locator('.inventory_item_name').textContent();
      const price = await item.locator('.inventory_item_price').textContent();
      await item.locator('button').click();
      console.log(`Added: ${name} - ${price}`);
    }
  }
}
