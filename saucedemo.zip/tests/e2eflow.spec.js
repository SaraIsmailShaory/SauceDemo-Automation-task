import { test } from '@playwright/test';
import { LoginPage } from '../pages/loginPage';
import { InventoryPage } from '../pages/inventoryPage';
import { CartPage } from '../pages/cartPage';
import { CheckoutPage } from '../pages/checkoutPage';
import { OrderConfirmationPage } from '../pages/orderConfirmationPage';

test.describe('End-to-End Purchase Flow', () => {
  test('should complete a full purchase successfully', async ({ page }) => {
    const login = new LoginPage(page);
    const inventory = new InventoryPage(page);
    const cart = new CartPage(page);
    const checkout = new CheckoutPage(page);
    const confirmation = new OrderConfirmationPage(page);

    await login.open();
    await login.login('standard_user', 'secret_sauce');

    await inventory.sortLowToHigh();
    await inventory.addTwoCheapestItems();

    await cart.openCart();
    await cart.validateCartItems();

    await checkout.fillCheckoutDetails({
      firstName: 'John',
      lastName: 'Doe',
      postalCode: '12345',
    });

    await checkout.completeOrder();
    await confirmation.verifySuccessMessage();
  });

  test('should show error for invalid credentials', async ({ page }) => {
    const login = new LoginPage(page);
    await login.open();
    await login.login('wrong_user', 'wrong_pass');
    await login.validateLoginError();
  });
});
